'''
Author Sampo Tanskanen

This code is copy from Adam Brickers code and it is slightly modified
to work properly with my data
'''

import pandas as pd
from scipy.stats import norm

#d' function
def dPrime(hitRate, FArate):
    stat = norm.ppf(hitRate) - norm.ppf(FArate)

    return stat

#criterion function
def criterion(hitRate, FArate):
    stat = -.5*(norm.ppf(hitRate) + norm.ppf(FArate))

    return stat

dataPath = "data/"
dataFile = "5_Behavioural experiment project_2021_Dec_09.csv"

rawData = pd.read_csv(dataPath + dataFile)

#a new data frame only with the data needed
expData = pd.DataFrame(rawData, columns = ["state" , "direction", "key_resp.keys", "key_resp.rt"])
#rename
expData = expData.rename(columns = {"state" : "condition", "direction" : "task",
                "key_resp.keys" : "resp", "key_resp.rt" : "RT"})

#the data frame we'll be using
accuracy = pd.DataFrame({"condition" : ["conscious", "unconscious"], "rHits" : [0,0], "rMisses" : [0,0],
                        "lHits" : [0,0], "lMisses" : [0,0]})

#updating the data frame for each entry
for index, row in expData.iterrows():
    #condition: conscious
    if row["condition"] == "conscious":
        rowInd = 0
        #Hit (right hit)
        if row["task"] == "right" and row["resp"] == "right":
            accuracy.loc[rowInd,"rHits"] += 1
        #Miss (right miss)
        elif row["task"] == "right" and row["resp"] == "left":
            accuracy.loc[rowInd,"rMisses"] += 1
        #Correct rejection (left hit)
        elif row["task"] == "left" and row["resp"] == "left":
            accuracy.loc[rowInd,"lHits"] += 1
        #False alarm (left miss)
        elif row["task"] == "left" and row["resp"] == "right":
            accuracy.loc[rowInd,"lMisses"] += 1

    #condition: unconscious
    elif row["condition"] == "unconscious":
        rowInd = 1
        #Hit (right hit)
        if row["task"] == "right" and row["resp"] == "right":
            accuracy.loc[rowInd,"rHits"] += 1
        #Miss (right miss)
        elif row["task"] == "right" and row["resp"] == "left":
            accuracy.loc[rowInd,"rMisses"] += 1
        #Correct rejection (left hit)
        elif row["task"] == "left" and row["resp"] == "left":
            accuracy.loc[rowInd,"lHits"] += 1
        #False alarm (left miss)
        elif row["task"] == "left" and row["resp"] == "right":
            accuracy.loc[rowInd,"lMisses"] += 1
            
print(accuracy)

#Calculate rates from response counts
hitRateConscious = accuracy.loc[0,"rHits"]/20
FArateConscious = accuracy.loc[0,"lMisses"]/20

hitRateUnconscious = accuracy.loc[1,"rHits"]/19
FArateUnconscious = accuracy.loc[1,"lMisses"]/20
#FArateHigh = (accuracy.loc[1,"lMisses"]+1)/15

#Cacluate d' and criterion
print("d' (conscious):", dPrime(hitRateConscious, FArateConscious))
print("criterion (conscious):", criterion(hitRateConscious, FArateConscious))

print("d' (unconscious):", dPrime(hitRateUnconscious, FArateUnconscious))
print("criterion (unconscious):", criterion(hitRateUnconscious, FArateUnconscious))
