'''
Author Sampo Tanskanen

This code is copy from Adam Brickers code and it is slightly modified
to work properly with my data
'''

import pandas as pd
import matplotlib.pyplot as plt

from statistics import mean
from os import listdir
from statsmodels.stats.anova import AnovaRM

##import data
dataPath = "data/"
fileList = listdir(dataPath)

#data frame for mean RTs
meanRTs = pd.DataFrame({"participant" : [], "state" : [],
                    "mean RT" : []})

counter = 0
for dataFile in fileList:
    #New ID for each participant
    counter += 1
    pNum = "P-" + str(counter)
    rawData = pd.read_csv(dataPath + dataFile)
    expData = pd.DataFrame(rawData, columns = ["state" , "direction", "key_resp.keys", "key_resp.rt",])
    expData = expData.rename(columns = {"key_resp.rt" : "RT", "key_resp.keys" : "response" })
    #only include trials with a response
    expData = expData[expData.RT.notnull()]
    rtData = expData[((expData.direction == "left") & (expData.response == "left")) | ((expData.response == "right") & (expData.response == "right"))] #attributions and rejections
    
    #data frame for RTs for each condition
    consciousLeftRTs = rtData[(rtData.state == "conscious") & (rtData.direction == "left")].RT
    consciousRightRTs = rtData[(rtData.state == "conscious") & (rtData.direction == "right")].RT

    unconsciousLeftRTs = rtData[(rtData.state == "unconscious") & (rtData.direction == "left")].RT
    unconsciousRightRTs = rtData[(rtData.state == "unconscious") & (rtData.direction == "right")].RT

    
    #lists for RTs for each condition
    consciousLeftRTs = []
    consciousRightRTs = []

    unconsciousLeftRTs = []
    unconsciousRightRTs = []
    count = 0
    #loop over data
    for index, row in rtData.iterrows():
        #filter data: correct response and non-empty RT
        #state = conscious and direction = left
        if row["state"] == "conscious" and row["direction"] == "left":
            consciousLeftRTs.append(row["RT"])
        #state = conscious and direction = right
        elif row["state"] == "conscious" and row["direction"] == "right":
            consciousRightRTs.append(row["RT"])
        #state = unconscious and direction = left
        elif row["state"] == "unconscious" and row["direction"] == "left":
            unconsciousLeftRTs.append(row["RT"])
        #state = unconscious and direction = right
        elif row["state"] == "unconscious" and row["direction"] == "right":
            unconsciousRightRTs.append(row["RT"])
        
    #new data to add to meanRTs
    pNumList = [pNum, pNum, pNum, pNum]
    stateList = ["conscious", "conscious", "unconscious", "unconscious"]
    directionList = ["left", "right", "left", "right"]
        
    meanRTsList = [mean(consciousLeftRTs), mean(consciousRightRTs), mean(unconsciousLeftRTs), mean(unconsciousRightRTs)]
            
    #new data --> data frame
    newLines = pd.DataFrame({"participant" : pNumList, "state" : stateList,
                            "direction" : directionList, "mean RT" : meanRTsList})
    meanRTs = meanRTs.append(newLines, ignore_index=True)

print(meanRTs)

#group means
consciousLeftMeans = meanRTs[(meanRTs.state == "conscious") & (meanRTs.direction == "left")]["mean RT"]
consciousRightMeans = meanRTs[(meanRTs.state == "conscious") & (meanRTs.direction == "right")]["mean RT"]
unconsciousLeftMeans = meanRTs[(meanRTs.state == "unconscious") & (meanRTs.direction == "left")]["mean RT"]
unconsciousRightMeans = meanRTs[(meanRTs.state == "unconscious") & (meanRTs.direction == "right")]["mean RT"]

print("Conscious, left RT:", mean(consciousLeftMeans))
print("Conscious, right mean RT:", mean(consciousRightMeans))
print("Unconscious, left mean RT:", mean(unconsciousLeftMeans))
print("Unconscious, right mean RT:", mean(unconsciousRightMeans))

#vizualizing with a boxplot
fig, ax = plt.subplots()

box = ax.boxplot([consciousLeftMeans, consciousRightMeans, unconsciousLeftMeans, unconsciousRightMeans])

ax.set_ylabel("RT (s)")
ax.set_xticklabels(["Conscious:Left", "Conscious:Right", "Unconscious:Left", "Unconscious:Right"])

plt.show()

#repeated measures anova
model = AnovaRM(data = meanRTs, depvar = "mean RT", subject = "participant", within = ["state", "direction"]).fit()

print (model)